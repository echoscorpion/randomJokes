<?php
/**
 * @package ny_jokes
 * @version 1
 */
/*
Plugin Name: Random Jokes
Description: This Puggin show random jokes to keep developers entertained.
Author: Batman
Version: 1.1
*/

 

function test_init(){
	?>
	<div class="wrap">
	<h1>Call Button</h1>

	</div>
	<?php 
}



function test_plugin() {
	$phone = get_option( 'test_plugin_phone_number' );
	$country = get_option( 'test_plugin_phone_country' );
	if(!is_admin()) {
		if (get_option('test_plugin_phone_number')){
				if(get_option( 'test_plugin_phone_position' )=='Right') {
					echo '<a class="ny-phone-link" href="tel:'.$country.''.$phone.'" style="background-color:'.get_option( 'test_plugin_phone_color' ).';"><div class="ny-call" style="right:10px;"><i class="fas fa-phone ny-p-i" style="transform: rotate(90deg);
					"></i></div></a>';
				}
				else {
					echo '<a class="ny-phone-link" href="tel:'.$country.''.$phone.'" style="background-color:'.get_option( 'test_plugin_phone_color' ).';"><div class="ny-call" style="left:10px;"><i class="fas fa-phone ny-p-i" style="transform: rotate(90deg);
					"></i></div></a>';
				}
		}
    }

}

add_action( 'init', 'test_plugin' );

// We need some CSS to position the button.
function test_plugin_css() {
	echo "
	<style type='text/css'>
	.ny-call{
		position: fixed;
		z-index: 11;
		padding: 20px;
		background: ".get_option( 'test_plugin_phone_color' ).";
		border-radius: 45px;
		bottom:20px;
		z-index:9999;
	}
	.ny-call:hover{
		transform:scale(1.2);
		transition-duration:.5s;
	}
	.ny-p-i {
		color:#fff!important;
	}

	@media screen and (max-width: 782px) {
		.ny-phone-link{
		display:none
		}
	}
	</style>
	";
}

add_action( 'init', 'test_plugin_css' );
